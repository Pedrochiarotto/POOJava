package Jogo;

public interface IBoss {
	
	public void armor();
	public void BuffForca();
	
}
