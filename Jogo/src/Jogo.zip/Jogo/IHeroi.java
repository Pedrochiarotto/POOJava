package Jogo;

public interface IHeroi {
    public void atacar();
    public void esquivar();
    public void usarHabilidadePrincipal();
    public void usarHabilidadeSecundaria();
}
