package Jogo;

public interface IInimigo {
}
