package Jogo;

public interface IInimigo {
	public void usarHabilidadeSecreta();
    public void atacar();
    public void esquivar();
    public void usarHabilidadePrincipal();
    public void usarHabilidadeSecundaria();
}
