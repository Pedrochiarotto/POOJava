package Jogo;

public class Ashe extends Personagem implements IHeroi {
    public Ashe(String nickname) {
        super(nickname, 10, 10, 10, 10, 10);
    }

	@Override
	public void atacar() {
		
		
	}

	@Override
	public void esquivar() {
		
		
	}

	@Override
	public void usarHabilidadePrincipal() {
		
		
	}

	@Override
	public void usarHabilidadeSecundaria() {
		
		
	}
}
